-- Insert sample data for testing

USE student_management_system;

-- Sample curriculum data
INSERT INTO curriculum (curriculum_year, title) VALUES 
('2024-2025', 'Revised Curriculum 2024'),
('2023-2024', 'Standard Curriculum 2023');

-- Sample program data
INSERT INTO program (curriculum_id, program_name, program_code, description) VALUES 
(1, 'Bachelor of Science in Computer Science', 'BSCS', 'Four-year degree program in Computer Science'),
(1, 'Bachelor of Science in Information Technology', 'BSIT', 'Four-year degree program in Information Technology'),
(2, 'Bachelor of Science in Computer Science', 'BSCS', 'Previous curriculum for Computer Science');

-- Sample faculty data
INSERT INTO faculty (faculty_number, first_name, last_name, email, department) VALUES 
('FAC001', 'John', 'Smith', 'john.smith@university.edu', 'Computer Science'),
('FAC002', 'Jane', 'Doe', 'jane.doe@university.edu', 'Information Technology'),
('FAC003', 'Robert', 'Johnson', 'robert.johnson@university.edu', 'Mathematics');

-- Sample student data
INSERT INTO student (student_number, first_name, last_name, email, program_id, year_level) VALUES 
('2024001', 'Alice', 'Brown', 'alice.brown@student.edu', 1, 1),
('2024002', 'Bob', 'Wilson', 'bob.wilson@student.edu', 1, 2),
('2024003', 'Carol', 'Davis', 'carol.davis@student.edu', 2, 1);
