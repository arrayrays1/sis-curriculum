-- Add soft delete columns to existing tables

USE student_management_system;

-- Add deleted_at column to curriculum table
ALTER TABLE curriculum 
ADD COLUMN deleted_at TIMESTAMP NULL DEFAULT NULL;

-- Add deleted_at column to program table
ALTER TABLE program 
ADD COLUMN deleted_at TIMESTAMP NULL DEFAULT NULL;

-- Add deleted_at column to subject table
ALTER TABLE subject 
ADD COLUMN deleted_at TIMESTAMP NULL DEFAULT NULL;

-- Add deleted_at column to student table
ALTER TABLE student 
ADD COLUMN deleted_at TIMESTAMP NULL DEFAULT NULL;

-- Add deleted_at column to faculty table
ALTER TABLE faculty 
ADD COLUMN deleted_at TIMESTAMP NULL DEFAULT NULL;

-- Add deleted_at column to faculty_subject_assignment table
ALTER TABLE faculty_subject_assignment 
ADD COLUMN deleted_at TIMESTAMP NULL DEFAULT NULL;

-- Add deleted_at column to student_enrollment table
ALTER TABLE student_enrollment 
ADD COLUMN deleted_at TIMESTAMP NULL DEFAULT NULL;

-- Create indexes for better performance on soft delete queries
CREATE INDEX idx_curriculum_deleted_at ON curriculum(deleted_at);
CREATE INDEX idx_program_deleted_at ON program(deleted_at);
CREATE INDEX idx_subject_deleted_at ON subject(deleted_at);
CREATE INDEX idx_student_deleted_at ON student(deleted_at);
CREATE INDEX idx_faculty_deleted_at ON faculty(deleted_at);
