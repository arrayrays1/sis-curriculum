-- Optional: Insert sample data for testing (only run this if you want sample data)

USE student_management_system;

-- Sample curriculum data
INSERT IGNORE INTO curriculum (curriculum_year, title, created_at, updated_at) VALUES 
('2024-2025', 'Revised Curriculum 2024', NOW(), NOW()),
('2023-2024', 'Standard Curriculum 2023', NOW(), NOW());

-- Sample program data (get curriculum IDs first)
SET @curriculum_2024 = (SELECT id FROM curriculum WHERE curriculum_year = '2024-2025' LIMIT 1);
SET @curriculum_2023 = (SELECT id FROM curriculum WHERE curriculum_year = '2023-2024' LIMIT 1);

INSERT IGNORE INTO program (curriculum_id, program_name, program_code, description, created_at) VALUES 
(@curriculum_2024, 'Bachelor of Science in Computer Science', 'BSCS', 'Four-year degree program in Computer Science', NOW()),
(@curriculum_2024, 'Bachelor of Science in Information Technology', 'BSIT', 'Four-year degree program in Information Technology', NOW()),
(@curriculum_2023, 'Bachelor of Science in Computer Science', 'BSCS', 'Previous curriculum for Computer Science', NOW());

-- Sample faculty data
INSERT IGNORE INTO faculty (faculty_number, first_name, last_name, email, department, created_at) VALUES 
('FAC001', 'John', 'Smith', 'john.smith@university.edu', 'Computer Science', NOW()),
('FAC002', 'Jane', 'Doe', 'jane.doe@university.edu', 'Information Technology', NOW()),
('FAC003', 'Robert', 'Johnson', 'robert.johnson@university.edu', 'Mathematics', NOW());

-- Sample student data
SET @program_bscs = (SELECT id FROM program WHERE program_code = 'BSCS' AND curriculum_id = @curriculum_2024 LIMIT 1);
SET @program_bsit = (SELECT id FROM program WHERE program_code = 'BSIT' AND curriculum_id = @curriculum_2024 LIMIT 1);

INSERT IGNORE INTO student (student_number, first_name, last_name, email, program_id, year_level, created_at) VALUES 
('2024001', 'Alice', 'Brown', 'alice.brown@student.edu', @program_bscs, 1, NOW()),
('2024002', 'Bob', 'Wilson', 'bob.wilson@student.edu', @program_bscs, 2, NOW()),
('2024003', 'Carol', 'Davis', 'carol.davis@student.edu', @program_bsit, 1, NOW());
