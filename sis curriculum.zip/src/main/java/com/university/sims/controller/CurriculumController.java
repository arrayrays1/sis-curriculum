package com.university.sims.controller;

import com.university.sims.entity.Curriculum;
import com.university.sims.entity.Program;
import com.university.sims.entity.Subject;
import com.university.sims.service.CurriculumService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.validation.Valid;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/curriculum")
public class CurriculumController {
    
    @Autowired
    private CurriculumService curriculumService;
    
    @GetMapping
    public String listCurricula(Model model) {
        List<Curriculum> curricula = curriculumService.getAllActiveCurricula();
        model.addAttribute("curricula", curricula);
        return "curriculum/list";
    }
    
    @GetMapping("/new")
    public String showNewCurriculumForm(Model model) {
        model.addAttribute("curriculum", new Curriculum());
        return "curriculum/form";
    }
    
    @PostMapping("/save")
    public String saveCurriculum(@ModelAttribute("curriculum") Curriculum curriculum, 
                                BindingResult result, 
                                RedirectAttributes redirectAttributes) {
        
        if (curriculumService.existsByCurriculumYear(curriculum.getCurriculumYear())) {
            result.rejectValue("curriculumYear", "error.curriculum", "Curriculum year already exists");
        }
        
        if (result.hasErrors()) {
            return "curriculum/form";
        }
        
        curriculumService.saveCurriculum(curriculum);
        redirectAttributes.addFlashAttribute("successMessage", "Curriculum created successfully!");
        return "redirect:/curriculum";
    }
    
    @GetMapping("/{id}/programs")
    public String viewCurriculumPrograms(@PathVariable Long id, Model model) {
        Optional<Curriculum> curriculum = curriculumService.getCurriculumById(id);
        if (curriculum.isPresent()) {
            List<Program> programs = curriculumService.getProgramsByCurriculumId(id);
            model.addAttribute("curriculum", curriculum.get());
            model.addAttribute("programs", programs);
            model.addAttribute("newProgram", new Program());
            return "curriculum/programs";
        }
        return "redirect:/curriculum";
    }
    
    @PostMapping("/{curriculumId}/programs/save")
    public String saveProgram(@PathVariable Long curriculumId,
                             @ModelAttribute("newProgram") Program program,
                             BindingResult result,
                             RedirectAttributes redirectAttributes) {
        
        Optional<Curriculum> curriculum = curriculumService.getCurriculumById(curriculumId);
        if (curriculum.isEmpty()) {
            return "redirect:/curriculum";
        }
        
        if (curriculumService.existsByProgramCodeAndCurriculumId(program.getProgramCode(), curriculumId)) {
            redirectAttributes.addFlashAttribute("errorMessage", "Program code already exists in this curriculum");
            return "redirect:/curriculum/" + curriculumId + "/programs";
        }
        
        program.setCurriculum(curriculum.get());
        curriculumService.saveProgram(program);
        redirectAttributes.addFlashAttribute("successMessage", "Program added successfully!");
        return "redirect:/curriculum/" + curriculumId + "/programs";
    }
    
    @GetMapping("/programs/{programId}/subjects")
    public String viewProgramSubjects(@PathVariable Long programId, Model model) {
        Optional<Program> program = curriculumService.getProgramById(programId);
        if (program.isPresent()) {
            List<Subject> subjects = curriculumService.getSubjectsByProgramId(programId);
            model.addAttribute("program", program.get());
            model.addAttribute("subjects", subjects);
            model.addAttribute("newSubject", new Subject());
            
            // Group subjects by year level for better display
            model.addAttribute("firstYearSubjects", curriculumService.getSubjectsByProgramIdAndYearLevel(programId, 1));
            model.addAttribute("secondYearSubjects", curriculumService.getSubjectsByProgramIdAndYearLevel(programId, 2));
            model.addAttribute("thirdYearSubjects", curriculumService.getSubjectsByProgramIdAndYearLevel(programId, 3));
            model.addAttribute("fourthYearSubjects", curriculumService.getSubjectsByProgramIdAndYearLevel(programId, 4));
            
            return "curriculum/subjects";
        }
        return "redirect:/curriculum";
    }
    
    @PostMapping("/programs/{programId}/subjects/save")
    public String saveSubject(@PathVariable Long programId,
                             @ModelAttribute("newSubject") Subject subject,
                             BindingResult result,
                             RedirectAttributes redirectAttributes) {
        
        Optional<Program> program = curriculumService.getProgramById(programId);
        if (program.isEmpty()) {
            return "redirect:/curriculum";
        }
        
        if (curriculumService.existsBySubjectCodeAndProgramId(subject.getSubjectCode(), programId)) {
            redirectAttributes.addFlashAttribute("errorMessage", "Subject code already exists in this program");
            return "redirect:/curriculum/programs/" + programId + "/subjects";
        }
        
        subject.setProgram(program.get());
        curriculumService.saveSubject(subject);
        redirectAttributes.addFlashAttribute("successMessage", "Subject added successfully!");
        return "redirect:/curriculum/programs/" + programId + "/subjects";
    }

    @GetMapping("/{id}/edit")
    public String showEditCurriculumForm(@PathVariable Long id, Model model) {
        Optional<Curriculum> curriculum = curriculumService.getCurriculumById(id);
        if (curriculum.isPresent()) {
            model.addAttribute("curriculum", curriculum.get());
            model.addAttribute("isEdit", true);
            return "curriculum/form";
        }
        return "redirect:/curriculum";
    }

    @PostMapping("/{id}/update")
    public String updateCurriculum(@PathVariable Long id,
                                  @ModelAttribute("curriculum") Curriculum curriculum,
                                  BindingResult result,
                                  RedirectAttributes redirectAttributes) {
        
        if (curriculumService.existsByCurriculumYearForUpdate(curriculum.getCurriculumYear(), id)) {
            result.rejectValue("curriculumYear", "error.curriculum", "Curriculum year already exists");
        }
        
        if (result.hasErrors()) {
            curriculum.setId(id);
            return "curriculum/form";
        }
        
        Optional<Curriculum> existingCurriculum = curriculumService.getCurriculumById(id);
        if (existingCurriculum.isPresent()) {
            Curriculum curr = existingCurriculum.get();
            curr.setCurriculumYear(curriculum.getCurriculumYear());
            curr.setTitle(curriculum.getTitle());
            curriculumService.saveCurriculum(curr);
            redirectAttributes.addFlashAttribute("successMessage", "Curriculum updated successfully!");
        }
        
        return "redirect:/curriculum";
    }

    @PostMapping("/{id}/delete")
    public String softDeleteCurriculum(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        curriculumService.softDeleteCurriculum(id);
        redirectAttributes.addFlashAttribute("successMessage", "Curriculum deleted successfully!");
        return "redirect:/curriculum";
    }

    @PostMapping("/programs/{id}/edit")
    public String showEditProgramForm(@PathVariable Long id, Model model) {
        Optional<Program> program = curriculumService.getProgramById(id);
        if (program.isPresent()) {
            model.addAttribute("program", program.get());
            model.addAttribute("curriculum", program.get().getCurriculum());
            model.addAttribute("programs", curriculumService.getProgramsByCurriculumId(program.get().getCurriculum().getId()));
            model.addAttribute("editProgram", program.get());
            return "curriculum/programs";
        }
        return "redirect:/curriculum";
    }

    @PostMapping("/programs/{id}/update")
    public String updateProgram(@PathVariable Long id,
                               @ModelAttribute("editProgram") Program program,
                               BindingResult result,
                               RedirectAttributes redirectAttributes) {
        
        Optional<Program> existingProgram = curriculumService.getProgramById(id);
        if (existingProgram.isEmpty()) {
            return "redirect:/curriculum";
        }
        
        Program existing = existingProgram.get();
        Long curriculumId = existing.getCurriculum().getId();
        
        if (curriculumService.existsByProgramCodeAndCurriculumIdForUpdate(program.getProgramCode(), curriculumId, id)) {
            redirectAttributes.addFlashAttribute("errorMessage", "Program code already exists in this curriculum");
            return "redirect:/curriculum/" + curriculumId + "/programs";
        }
        
        existing.setProgramName(program.getProgramName());
        existing.setProgramCode(program.getProgramCode());
        existing.setDescription(program.getDescription());
        curriculumService.saveProgram(existing);
        
        redirectAttributes.addFlashAttribute("successMessage", "Program updated successfully!");
        return "redirect:/curriculum/" + curriculumId + "/programs";
    }

    @PostMapping("/programs/{id}/delete")
    public String softDeleteProgram(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        Optional<Program> program = curriculumService.getProgramById(id);
        if (program.isPresent()) {
            Long curriculumId = program.get().getCurriculum().getId();
            curriculumService.softDeleteProgram(id);
            redirectAttributes.addFlashAttribute("successMessage", "Program deleted successfully!");
            return "redirect:/curriculum/" + curriculumId + "/programs";
        }
        return "redirect:/curriculum";
    }

    @PostMapping("/subjects/{id}/update")
    public String updateSubject(@PathVariable Long id,
                               @ModelAttribute("editSubject") Subject subject,
                               BindingResult result,
                               RedirectAttributes redirectAttributes) {
        
        Optional<Subject> existingSubject = curriculumService.getSubjectById(id);
        if (existingSubject.isEmpty()) {
            return "redirect:/curriculum";
        }
        
        Subject existing = existingSubject.get();
        Long programId = existing.getProgram().getId();
        
        if (curriculumService.existsBySubjectCodeAndProgramIdForUpdate(subject.getSubjectCode(), programId, id)) {
            redirectAttributes.addFlashAttribute("errorMessage", "Subject code already exists in this program");
            return "redirect:/curriculum/programs/" + programId + "/subjects";
        }
        
        existing.setSubjectCode(subject.getSubjectCode());
        existing.setCourseTitle(subject.getCourseTitle());
        existing.setUnits(subject.getUnits());
        existing.setYearLevel(subject.getYearLevel());
        existing.setSemester(subject.getSemester());
        curriculumService.saveSubject(existing);
        
        redirectAttributes.addFlashAttribute("successMessage", "Subject updated successfully!");
        return "redirect:/curriculum/programs/" + programId + "/subjects";
    }

    @PostMapping("/subjects/{id}/delete")
    public String softDeleteSubject(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        Optional<Subject> subject = curriculumService.getSubjectById(id);
        if (subject.isPresent()) {
            Long programId = subject.get().getProgram().getId();
            curriculumService.softDeleteSubject(id);
            redirectAttributes.addFlashAttribute("successMessage", "Subject deleted successfully!");
            return "redirect:/curriculum/programs/" + programId + "/subjects";
        }
        return "redirect:/curriculum";
    }
}
