package com.university.sims.service;

import com.university.sims.entity.Curriculum;
import com.university.sims.entity.Program;
import com.university.sims.entity.Subject;
import com.university.sims.repository.CurriculumRepository;
import com.university.sims.repository.ProgramRepository;
import com.university.sims.repository.SubjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class CurriculumService {
    
    @Autowired
    private CurriculumRepository curriculumRepository;
    
    @Autowired
    private ProgramRepository programRepository;
    
    @Autowired
    private SubjectRepository subjectRepository;
    
    // Curriculum methods
    public List<Curriculum> getAllActiveCurricula() {
        return curriculumRepository.findAllActive();
    }
    
    public Optional<Curriculum> getCurriculumById(Long id) {
        return curriculumRepository.findByIdAndNotDeleted(id);
    }
    
    public Curriculum saveCurriculum(Curriculum curriculum) {
        return curriculumRepository.save(curriculum);
    }
    
    public boolean existsByCurriculumYear(String curriculumYear) {
        return curriculumRepository.existsByCurriculumYearAndNotDeleted(curriculumYear);
    }
    
    public boolean existsByCurriculumYearForUpdate(String curriculumYear, Long id) {
        return curriculumRepository.existsByCurriculumYearAndNotDeletedAndIdNot(curriculumYear, id);
    }
    
    public void softDeleteCurriculum(Long id) {
        Optional<Curriculum> curriculum = curriculumRepository.findById(id);
        if (curriculum.isPresent()) {
            curriculum.get().softDelete();
            curriculumRepository.save(curriculum.get());
        }
    }
    
    // Program methods
    public List<Program> getProgramsByCurriculumId(Long curriculumId) {
        return programRepository.findByCurriculumIdAndNotDeleted(curriculumId);
    }
    
    public Optional<Program> getProgramById(Long id) {
        return programRepository.findByIdAndNotDeleted(id);
    }
    
    public Program saveProgram(Program program) {
        return programRepository.save(program);
    }
    
    public boolean existsByProgramCodeAndCurriculumId(String programCode, Long curriculumId) {
        return programRepository.existsByProgramCodeAndCurriculumIdAndNotDeleted(programCode, curriculumId);
    }
    
    public boolean existsByProgramCodeAndCurriculumIdForUpdate(String programCode, Long curriculumId, Long id) {
        return programRepository.existsByProgramCodeAndCurriculumIdAndNotDeletedAndIdNot(programCode, curriculumId, id);
    }
    
    public void softDeleteProgram(Long id) {
        Optional<Program> program = programRepository.findById(id);
        if (program.isPresent()) {
            program.get().softDelete();
            programRepository.save(program.get());
        }
    }
    
    // Subject methods
    public List<Subject> getSubjectsByProgramId(Long programId) {
        return subjectRepository.findByProgramIdAndNotDeleted(programId);
    }
    
    public List<Subject> getSubjectsByProgramIdAndYearLevel(Long programId, Integer yearLevel) {
        return subjectRepository.findByProgramIdAndYearLevelAndNotDeleted(programId, yearLevel);
    }
    
    public Optional<Subject> getSubjectById(Long id) {
        return subjectRepository.findByIdAndNotDeleted(id);
    }
    
    public Subject saveSubject(Subject subject) {
        return subjectRepository.save(subject);
    }
    
    public boolean existsBySubjectCodeAndProgramId(String subjectCode, Long programId) {
        return subjectRepository.existsBySubjectCodeAndProgramIdAndNotDeleted(subjectCode, programId);
    }
    
    public boolean existsBySubjectCodeAndProgramIdForUpdate(String subjectCode, Long programId, Long id) {
        return subjectRepository.existsBySubjectCodeAndProgramIdAndNotDeletedAndIdNot(subjectCode, programId, id);
    }
    
    public void softDeleteSubject(Long id) {
        Optional<Subject> subject = subjectRepository.findById(id);
        if (subject.isPresent()) {
            subject.get().softDelete();
            subjectRepository.save(subject.get());
        }
    }
}
