package com.university.sims.repository;

import com.university.sims.entity.Program;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface ProgramRepository extends JpaRepository<Program, Long> {
    
    // Find programs by curriculum ID (non-deleted only)
    @Query("SELECT p FROM Program p WHERE p.curriculum.id = :curriculumId AND p.deletedAt IS NULL ORDER BY p.programName")
    List<Program> findByCurriculumIdAndNotDeleted(@Param("curriculumId") Long curriculumId);
    
    // Find by ID (non-deleted only)
    @Query("SELECT p FROM Program p WHERE p.id = :id AND p.deletedAt IS NULL")
    Optional<Program> findByIdAndNotDeleted(@Param("id") Long id);
    
    // Check if program code exists in curriculum (non-deleted only)
    @Query("SELECT COUNT(p) > 0 FROM Program p WHERE p.programCode = :programCode AND p.curriculum.id = :curriculumId AND p.deletedAt IS NULL")
    boolean existsByProgramCodeAndCurriculumIdAndNotDeleted(@Param("programCode") String programCode, @Param("curriculumId") Long curriculumId);
    
    // Check if program code exists for update (excluding current ID)
    @Query("SELECT COUNT(p) > 0 FROM Program p WHERE p.programCode = :programCode AND p.curriculum.id = :curriculumId AND p.id != :id AND p.deletedAt IS NULL")
    boolean existsByProgramCodeAndCurriculumIdAndNotDeletedAndIdNot(@Param("programCode") String programCode, @Param("curriculumId") Long curriculumId, @Param("id") Long id);
}
