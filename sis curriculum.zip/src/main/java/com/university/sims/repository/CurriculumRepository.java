package com.university.sims.repository;

import com.university.sims.entity.Curriculum;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface CurriculumRepository extends JpaRepository<Curriculum, Long> {
    
    // Find all non-deleted curricula
    @Query("SELECT c FROM Curriculum c WHERE c.deletedAt IS NULL ORDER BY c.createdAt DESC")
    List<Curriculum> findAllActive();
    
    // Find by curriculum year (non-deleted only)
    @Query("SELECT c FROM Curriculum c WHERE c.curriculumYear = :curriculumYear AND c.deletedAt IS NULL")
    Optional<Curriculum> findByCurriculumYearAndNotDeleted(@Param("curriculumYear") String curriculumYear);
    
    // Find by ID (non-deleted only)
    @Query("SELECT c FROM Curriculum c WHERE c.id = :id AND c.deletedAt IS NULL")
    Optional<Curriculum> findByIdAndNotDeleted(@Param("id") Long id);
    
    // Check if curriculum year exists (non-deleted only)
    @Query("SELECT COUNT(c) > 0 FROM Curriculum c WHERE c.curriculumYear = :curriculumYear AND c.deletedAt IS NULL")
    boolean existsByCurriculumYearAndNotDeleted(@Param("curriculumYear") String curriculumYear);
    
    // Check if curriculum year exists for update (excluding current ID)
    @Query("SELECT COUNT(c) > 0 FROM Curriculum c WHERE c.curriculumYear = :curriculumYear AND c.id != :id AND c.deletedAt IS NULL")
    boolean existsByCurriculumYearAndNotDeletedAndIdNot(@Param("curriculumYear") String curriculumYear, @Param("id") Long id);
}
