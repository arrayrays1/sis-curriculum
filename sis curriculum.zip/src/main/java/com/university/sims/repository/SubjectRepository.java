package com.university.sims.repository;

import com.university.sims.entity.Subject;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface SubjectRepository extends JpaRepository<Subject, Long> {
    
    // Find subjects by program ID (non-deleted only)
    @Query("SELECT s FROM Subject s WHERE s.program.id = :programId AND s.deletedAt IS NULL ORDER BY s.yearLevel, s.semester, s.subjectCode")
    List<Subject> findByProgramIdAndNotDeleted(@Param("programId") Long programId);
    
    // Find subjects by program ID and year level (non-deleted only)
    @Query("SELECT s FROM Subject s WHERE s.program.id = :programId AND s.yearLevel = :yearLevel AND s.deletedAt IS NULL ORDER BY s.semester, s.subjectCode")
    List<Subject> findByProgramIdAndYearLevelAndNotDeleted(@Param("programId") Long programId, @Param("yearLevel") Integer yearLevel);
    
    // Find by ID (non-deleted only)
    @Query("SELECT s FROM Subject s WHERE s.id = :id AND s.deletedAt IS NULL")
    Optional<Subject> findByIdAndNotDeleted(@Param("id") Long id);
    
    // Check if subject code exists in program (non-deleted only)
    @Query("SELECT COUNT(s) > 0 FROM Subject s WHERE s.subjectCode = :subjectCode AND s.program.id = :programId AND s.deletedAt IS NULL")
    boolean existsBySubjectCodeAndProgramIdAndNotDeleted(@Param("subjectCode") String subjectCode, @Param("programId") Long programId);
    
    // Check if subject code exists for update (excluding current ID)
    @Query("SELECT COUNT(s) > 0 FROM Subject s WHERE s.subjectCode = :subjectCode AND s.program.id = :programId AND s.id != :id AND s.deletedAt IS NULL")
    boolean existsBySubjectCodeAndProgramIdAndNotDeletedAndIdNot(@Param("subjectCode") String subjectCode, @Param("programId") Long programId, @Param("id") Long id);
}
