package com.university.sims.config;

import com.university.sims.entity.Curriculum;
import com.university.sims.entity.Program;
import com.university.sims.entity.Subject;
import com.university.sims.service.CurriculumService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component  // Uncomment this to enable sample data
public class DataInitializer implements CommandLineRunner {
    
    @Autowired
    private CurriculumService curriculumService;
    
    @Override
    public void run(String... args) throws Exception {
        // Initialize with sample data
        initializeSampleData();
        System.out.println("🚀 Application started with sample data");
    }
    
    private void initializeSampleData() {
        // Create sample curriculum
        Curriculum curriculum2024 = new Curriculum("2024-2025", "Revised Curriculum 2024");
        curriculum2024 = curriculumService.saveCurriculum(curriculum2024);
        
        Curriculum curriculum2023 = new Curriculum("2023-2024", "Standard Curriculum 2023");
        curriculum2023 = curriculumService.saveCurriculum(curriculum2023);
        
        // Create sample programs for 2024-2025
        Program bscs = new Program(
            "Bachelor of Science in Computer Science", 
            "BSCS", 
            "Four-year degree program in Computer Science", 
            curriculum2024
        );
        bscs = curriculumService.saveProgram(bscs);
        
        Program bsit = new Program(
            "Bachelor of Science in Information Technology", 
            "BSIT", 
            "Four-year degree program in Information Technology", 
            curriculum2024
        );
        bsit = curriculumService.saveProgram(bsit);
        
        // Create sample subjects for BSCS
        createSampleSubjects(bscs);
        createSampleSubjects(bsit);
        
        System.out.println("✅ Sample data initialized successfully!");
    }
    
    private void createSampleSubjects(Program program) {
        // First Year Subjects
        curriculumService.saveSubject(new Subject("MATH101", "College Algebra", 3, 1, 1, program));
        curriculumService.saveSubject(new Subject("ENG101", "English Communication", 3, 1, 1, program));
        curriculumService.saveSubject(new Subject("CS101", "Introduction to Programming", 3, 1, 1, program));
        curriculumService.saveSubject(new Subject("PE101", "Physical Education 1", 2, 1, 1, program));
        
        curriculumService.saveSubject(new Subject("MATH102", "Trigonometry", 3, 1, 2, program));
        curriculumService.saveSubject(new Subject("ENG102", "Technical Writing", 3, 1, 2, program));
        curriculumService.saveSubject(new Subject("CS102", "Programming Fundamentals", 3, 1, 2, program));
        curriculumService.saveSubject(new Subject("PE102", "Physical Education 2", 2, 1, 2, program));
        
        // Second Year Subjects
        curriculumService.saveSubject(new Subject("MATH201", "Calculus I", 3, 2, 1, program));
        curriculumService.saveSubject(new Subject("CS201", "Data Structures", 3, 2, 1, program));
        curriculumService.saveSubject(new Subject("CS202", "Object-Oriented Programming", 3, 2, 1, program));
        
        curriculumService.saveSubject(new Subject("MATH202", "Calculus II", 3, 2, 2, program));
        curriculumService.saveSubject(new Subject("CS203", "Database Systems", 3, 2, 2, program));
        curriculumService.saveSubject(new Subject("CS204", "Web Development", 3, 2, 2, program));
    }
}
