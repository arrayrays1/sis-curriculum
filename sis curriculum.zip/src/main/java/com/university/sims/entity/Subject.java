package com.university.sims.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "subject")
public class Subject {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "subject_code", nullable = false)
    private String subjectCode;
    
    @Column(name = "course_title", nullable = false)
    private String courseTitle;
    
    @Column(name = "units", nullable = false)
    private Integer units;
    
    @Column(name = "year_level", nullable = false)
    private Integer yearLevel;
    
    @Column(name = "semester")
    private Integer semester = 1;
    
    @Column(name = "created_at")
    private LocalDateTime createdAt;
    
    @Column(name = "deleted_at")
    private LocalDateTime deletedAt;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "program_id", nullable = false)
    private Program program;
    
    // Constructors
    public Subject() {}
    
    public Subject(String subjectCode, String courseTitle, Integer units, Integer yearLevel, Integer semester, Program program) {
        this.subjectCode = subjectCode;
        this.courseTitle = courseTitle;
        this.units = units;
        this.yearLevel = yearLevel;
        this.semester = semester;
        this.program = program;
        this.createdAt = LocalDateTime.now();
    }
    
    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getSubjectCode() { return subjectCode; }
    public void setSubjectCode(String subjectCode) { this.subjectCode = subjectCode; }
    
    public String getCourseTitle() { return courseTitle; }
    public void setCourseTitle(String courseTitle) { this.courseTitle = courseTitle; }
    
    public Integer getUnits() { return units; }
    public void setUnits(Integer units) { this.units = units; }
    
    public Integer getYearLevel() { return yearLevel; }
    public void setYearLevel(Integer yearLevel) { this.yearLevel = yearLevel; }
    
    public Integer getSemester() { return semester; }
    public void setSemester(Integer semester) { this.semester = semester; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public LocalDateTime getDeletedAt() { return deletedAt; }
    public void setDeletedAt(LocalDateTime deletedAt) { this.deletedAt = deletedAt; }
    
    public Program getProgram() { return program; }
    public void setProgram(Program program) { this.program = program; }
    
    // Soft delete method
    public void softDelete() {
        this.deletedAt = LocalDateTime.now();
    }
    
    // Check if soft deleted
    public boolean isDeleted() {
        return this.deletedAt != null;
    }
    
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }
}
